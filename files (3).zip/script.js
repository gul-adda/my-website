(function () {
  'use strict';

  // ====== EDIT THESE ======
  var WHATSAPP_NUMBER = '923001234567'; // country code + number, no + or spaces
  // ========================

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  // Footer year
  $('#year').textContent = new Date().getFullYear();

  // Mobile menu
  var menuBtn = $('#menuBtn');
  var nav = $('#nav');

  function setMenu(open) {
    nav.classList.toggle('open', open);
    menuBtn.setAttribute('aria-expanded', String(open));
    menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
  }

  menuBtn.addEventListener('click', function () {
    setMenu(!nav.classList.contains('open'));
  });
  $$('a', nav).forEach(function (a) {
    a.addEventListener('click', function () { setMenu(false); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') setMenu(false);
  });

  // Hero colour swatches
  var stage = $('#stage');
  var dress = $('.big-dress');
  $$('.sw').forEach(function (btn) {
    btn.addEventListener('click', function () {
      $$('.sw').forEach(function (b) {
        b.classList.remove('is-on');
        b.setAttribute('aria-checked', 'false');
      });
      btn.classList.add('is-on');
      btn.setAttribute('aria-checked', 'true');
      stage.style.setProperty('--c', btn.dataset.c);
      stage.style.setProperty('--bg', btn.dataset.bg);
      dress.classList.remove('sway');
      void dress.getBoundingClientRect(); // restart animation
      dress.classList.add('sway');
    });
  });

  // Collection filter
  var chips = $$('.chip');
  var cards = $$('.card');
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('is-on'); });
      chip.classList.add('is-on');
      var f = chip.dataset.f;
      cards.forEach(function (card) {
        card.classList.toggle('hide', f !== 'all' && card.dataset.cat !== f);
      });
    });
  });

  // "Order" links pre-select the dress in the form
  var itemSelect = $('#item');
  $$('.link[data-item]').forEach(function (link) {
    link.addEventListener('click', function () {
      itemSelect.value = link.dataset.item;
    });
  });

  // Contact form -> WhatsApp
  var form = $('#form');
  var err = $('#err');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var name = form.name.value.trim();
    var msg = form.msg.value.trim();
    if (!name || !msg) {
      err.hidden = false;
      (name ? form.msg : form.name).focus();
      return;
    }
    err.hidden = true;
    var text = 'Hi Aira Dresses, I am ' + name + '.\n' +
      'Dress: ' + form.item.value + '\n' +
      'Details: ' + msg;
    var url = 'https://wa.me/' + WHATSAPP_NUMBER + '?text=' + encodeURIComponent(text);
    window.open(url, '_blank', 'noopener');
  });
})();
